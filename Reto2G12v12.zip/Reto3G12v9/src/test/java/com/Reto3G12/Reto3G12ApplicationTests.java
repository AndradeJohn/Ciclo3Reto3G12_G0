package com.Reto3G12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3G12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
