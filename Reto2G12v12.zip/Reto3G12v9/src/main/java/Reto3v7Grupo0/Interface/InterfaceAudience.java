

package Reto3v7Grupo0.Interface;

import Reto3v7Grupo0.Modelo.Audience;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author John Andrade
 */

public interface InterfaceAudience extends CrudRepository<Audience, Integer>{

}
