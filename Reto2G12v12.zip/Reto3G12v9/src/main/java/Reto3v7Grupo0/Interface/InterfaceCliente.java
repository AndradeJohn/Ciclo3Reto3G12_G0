

package Reto3v7Grupo0.Interface;

import Reto3v7Grupo0.Modelo.Cliente;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author John Andrade
 */
public interface InterfaceCliente extends CrudRepository<Cliente, Integer>{

}
